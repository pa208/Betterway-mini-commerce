export default function Cart({ cart }) {
  if (!cart.items.length) return <p>Cart is empty.</p>;

  return (
    <div className="cart">
      <h3>Cart</h3>

      {cart.items.map(item => (
        <div key={item.id} className="cart-item">
          <span>{item.title}</span>
          <input
            type="number"
            min="1"
            value={item.qty}
            onChange={e =>
              cart.updateQty(item.id, Number(e.target.value), item.stock)
            }
          />
          <button onClick={() => cart.removeFromCart(item.id)}>Remove</button>
        </div>
      ))}

      <hr />
      <p>Total Items: {cart.totalItems}</p>
      <p>Total Price: ₹{cart.totalPrice.toFixed(2)}</p>
    </div>
  );
}
