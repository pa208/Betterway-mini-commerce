import { useEffect, useState } from "react";

export function useCart() {
  const [items, setItems] = useState(() => {
    const saved = localStorage.getItem("cart");
    return saved ? JSON.parse(saved) : [];
  });

  useEffect(() => {
    localStorage.setItem("cart", JSON.stringify(items));
  }, [items]);

  const addToCart = product => {
    setItems(prev => {
      const found = prev.find(p => p.id === product.id);
      if (found) {
        if (found.qty < product.stock) {
          return prev.map(p =>
            p.id === product.id ? { ...p, qty: p.qty + 1 } : p
          );
        }
        return prev;
      }
      return [...prev, { ...product, qty: 1 }];
    });
  };

  const removeFromCart = id =>
    setItems(prev => prev.filter(p => p.id !== id));

  const updateQty = (id, qty, stock) =>
    setItems(prev =>
      prev.map(p =>
        p.id === id ? { ...p, qty: Math.min(qty, stock) } : p
      )
    );

  const totalItems = items.reduce((sum, p) => sum + p.qty, 0);
  const totalPrice = items.reduce((sum, p) => sum + p.qty * p.price, 0);

  return { items, addToCart, removeFromCart, updateQty, totalItems, totalPrice };
}
